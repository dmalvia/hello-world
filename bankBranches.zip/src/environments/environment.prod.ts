export const environment = {
  production: true,
  baseUrl:'https://api.halifax.co.uk/open-banking/v2.2/'
};
