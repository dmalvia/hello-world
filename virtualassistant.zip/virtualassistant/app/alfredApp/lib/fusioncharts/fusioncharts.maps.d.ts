
import { FusionChartStatic } from "fusioncharts";

declare namespace Maps {}
declare var Maps: (H: FusionChartStatic) => FusionChartStatic;
export = Maps;
export as namespace Maps;

