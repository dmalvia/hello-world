
import { FusionChartStatic } from "fusioncharts";

declare namespace Zune {}
declare var Zune: (H: FusionChartStatic) => FusionChartStatic;
export = Zune;
export as namespace Zune;

