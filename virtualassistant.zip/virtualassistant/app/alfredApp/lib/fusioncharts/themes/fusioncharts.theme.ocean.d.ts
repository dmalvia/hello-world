
import { FusionChartStatic } from "fusioncharts";

declare namespace Ocean {}
declare var Ocean: (H: FusionChartStatic) => FusionChartStatic;
export = Ocean;
export as namespace Ocean;

